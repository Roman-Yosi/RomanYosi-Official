# MusicNewsID — Roman Yosi

Repositori ini berisi dua situs statis dalam satu repositori:
- **Root (`/`)**: situs resmi artis Roman Yosi.
- **`news-site/`**: portal publikasi Music News ID untuk subdomain `news.romanyosi.com`.

## 1. Deploy situs utama (Netlify yang sudah terhubung)
Pengaturan proyek Netlify utama:
- Repository: `Roman-Yosi/MusicNewsID`
- Build command: kosong
- Publish directory: `.`
- Base directory: kosong
- Build status: aktif

Situs utama menggunakan isi folder root repositori.

## 2. Deploy portal berita sebagai proyek Netlify kedua
Agar subdomain benar-benar terpisah, buat **proyek Netlify kedua**:
1. Netlify → Add new project → Import an existing project.
2. Pilih GitHub repository `Roman-Yosi/MusicNewsID` yang sama.
3. Base directory: kosong.
4. Build command: kosong.
5. Publish directory: `news-site`.
6. Deploy.

Setelah proyek kedua aktif, buka Domain management pada proyek kedua dan tambahkan `news.romanyosi.com` sebagai custom domain.

## 3. DNS subdomain
Di pengelola DNS domain `romanyosi.com`, tambahkan record sesuai target yang ditampilkan Netlify untuk proyek berita. Umumnya Netlify meminta:
- Type: CNAME
- Host/Name: `news`
- Target/Value: hostname Netlify proyek berita (mis. `nama-proyek.netlify.app`)

Gunakan nilai target yang Netlify tampilkan, bukan contoh di atas. Tunggu propagasi DNS dan aktifkan HTTPS/SSL di Netlify.

## 4. Hubungkan domain utama
Proyek utama perlu domain `romanyosi.com` (atau domain utama yang benar-benar kamu miliki) di Domain management proyek utama. Atur DNS sesuai instruksi Netlify.

## 5. Cara memperbarui artikel
Tambahkan file HTML di `news-site/artikel/`, lalu tautkan dari `news-site/index.html` dan perbarui `news-site/sitemap.xml`. Tulis tanggal publikasi, penulis, dan sumber yang dapat diverifikasi untuk setiap artikel berita.

## 6. Catatan penting
- Domain `romanyosi.com` hanya contoh alamat target. Pastikan domain sudah dimiliki dan DNS bisa kamu kelola.
- Foto profil menggunakan URL gambar GitHub yang sudah disediakan. Ganti jika URL gambar berubah.
- Konten contoh adalah profil/katalog dasar, bukan klaim pemberitaan independen atau liputan media pihak ketiga.
- Setelah perubahan di-push ke GitHub, kedua proyek Netlify akan membangun ulang secara otomatis jika keduanya terhubung ke repositori.
